package com.coursemanagement.app.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.coursemanagement.app.entity.Instructor;
import com.coursemanagement.app.entity.Student;
import com.coursemanagement.app.entity.RandomUser;
import com.coursemanagement.app.enum1.Role;
import com.coursemanagement.app.repository.InstructorRepository;
import com.coursemanagement.app.repository.StudentRepository;
import com.coursemanagement.app.repository.UserRepository;


@Service
public class UserService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private InstructorRepository instructorRepository;

    @Autowired
    private StudentRepository studentRepository;

    public RandomUser registerUser(RandomUser user) {
        RandomUser savedUser = userRepository.save(user);

        if (user.getRole() == Role.INSTRUCTOR) {
            // Save to the instructor table
            Instructor instructor = new Instructor();
            instructor.setName(user.getName());
            instructor.setEmail(user.getEmail());
            instructor.setPassword(user.getPassword());
            instructorRepository.save(instructor);
        } else if (user.getRole() == Role.STUDENT) {
            // Save to the student table
            Student student = new Student();
            student.setName(user.getName());
            student.setEmail(user.getEmail());
            student.setPassword(user.getPassword());
            studentRepository.save(student);
        }

        return savedUser;
    }

    public Optional<RandomUser> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }
}