package com.coursemanagement.app.enum1;

public enum Role {
	ADMIN,
    STUDENT,
    INSTRUCTOR;
}
