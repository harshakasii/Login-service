package com.coursemanagement.app.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.coursemanagement.app.entity.RandomUser;
import org.springframework.web.bind.annotation.RestController;
import com.coursemanagement.app.enum1.Role;
import com.coursemanagement.app.service.UserService;

@RestController
@RequestMapping("/auth")
public class AuthController {
    @Autowired
    private UserService userService;

    private static final String ADMIN_EMAIL = "admin@gmail.com";
    private static final String ADMIN_PASSWORD = "admin123";

    @PostMapping("/register")
    public String register(@RequestBody RandomUser user) {
    	System.out.println("Received registration request for: " + user.getEmail());
        if (user.getRole() == Role.ADMIN) {
            return "Admin registration is not allowed.";
        }

        userService.registerUser(user);
        return "User registered successfully!";
    }

    @PostMapping("/login")
    public String login(@RequestParam String email, @RequestParam String password, @RequestParam Role role) {
        if (email.equals(ADMIN_EMAIL) && password.equals(ADMIN_PASSWORD)) {
            return "Admin login successful! Redirecting to Admin Service...";
        }

        Optional<RandomUser> user = userService.findByEmail(email);
        if (user.isPresent() && user.get().getPassword().equals(password) && user.get().getRole() == role) {
            if (role == Role.STUDENT) {
                return "Student login successful! Redirecting to Student Service...";
            } else if (role == Role.INSTRUCTOR) {
                return "Instructor login successful! Redirecting to Instructor Service...";
            }
        }

        return "Invalid credentials or role.";
    }
}