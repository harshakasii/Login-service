package com.coursemanagement.app.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.coursemanagement.app.entity.RandomUser;


@Repository
public interface UserRepository extends JpaRepository<RandomUser, Long> {
    Optional<RandomUser> findByEmail(String email);
}